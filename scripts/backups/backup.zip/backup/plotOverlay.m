function [varargout] = plotOverlay(underlay, overlayData, varargin)
% Plot statistical data (i.e., overlay), either on top of an underlay
% figure (i.e., brain surface(s)) that you have already generated, or after
% generating an underlay figure from scratch using underlay data that is
% provided.
%
% Basic call:
% [overlay] = plotUnderlay(underlay, overlayData)
%
% The call to plotOverlay must include an underlay structure in 'underlay',
% and some overlay data in 'overlayData'.
%
% Mandatory variables:
% underlay -- underlay must have at least one and up to two fields. The
% fields are 'left' and/or 'right', corresponding to data about either the
% left or right hemisphere. In both 'left' and 'right' fields there must be
% a 'Faces' field, a 'Vertices' field and a 'FaceVertexCData' field. Faces
% and vertices can be read in from any surface space nifti file using
% load_nifti. FaceVertexCData has as many rows as there are 'Vertices'. It
% has 3 columns and corresponds to a color associated with every individual
% vertex (in this case corresponding to sulci and gyri). This data can be
% read in from a .curv file with read_curv or generated through
% plotUnderlay, which will allow you to edit the color of the
% sulci/gyri. Can be patch object (e.g., from plotUnderlay).
%
% overlayData -- this is the statistical data you want to patch on top of
% the underlay. It should have one column and as many rows as there are
% vertices (i.e., you need a data point for each vertex).
%
% Optional variables:
% 'hemisphere' -- this string tells the script which hemisphere the overlay
% data is to be patched on. It can either be 'lh' or 'rh'. Alternatively,
% you can pass along any filename as long as it contains either a 'lh' or a
% 'rh' string.
%
% 'figHandle' -- this is the handle to a figure you want
% to patch statistical data on top of (i.e., the underlay). If this is not
% provided, an underlay will be created using data in the 'underlay'
% structure.
%
% 'multiOverlay' -- if this string is 'on' then any prior overlays that are
% supplied with the 'overlay' argument will not be be deleted prior to
% patching of current data (i.e., the output of this script will not
% contain a handle by which you can alter prior overlays).
%
% 'threshold' -- this is a two digit threshold for statistical data. The
% digits represent the minimum and maximum values that will be removed from
% the data. All statistcal data falling in between these two values (i.e.,
% threshold(1):threshold(2)) will be removed from the overlay patch by
% deleting all patches that involve the thresholded vertices. If your data
% only contains positive or negative values, you can make either the
% minimum or maximum threshold 0. For example, if my map contains only
% positive correlations, a minimum threshold of 0 and a maximum threshold
% of 0.5 will remove all values between 0 and 0.5. Default is no threshold
% (i.e., [0 0]).
%
% 'limits' -- this two digit array sets the color axis limits (i.e., the
% maximum and minimum statistical data points asscoiated with the maximum
% and minimum colors in the colorMap you selected). Default is an empty
% variable that will be based on the min/max of your overlay data.
%
% 'opacity' -- this sets the opacity of he patch. Default is 1.
%
% 'colorMap' -- this string determines which colormap will be used. This can
% be set to any colorMap that is supported in matlab. It can also be set to
% 'custom'. Default is 'jet'.
%
% 'colorSampling' -- this string can either be set to 'even' or 'uneven'. In
% the case of 'even' the spacing of colors on your selected colorMap will
% be linear between the color axis limits. In the case of uneven, both
% positive and negative values in your overlay will get half the color
% spectrum in the colorMap you've selected. If my limits are from -20 to
% 100, then values between -20 to 0, and values between 0 to 100 will each
% get half the colors in colorMap. Default is 'uneven'.
%
% 'colorBins' -- this digit will set the number of different colors you want
% within the colorMap you have selected. Default is 1000.
%
% 'pMap' -- you can also pass along p-values for each of the data points you
% are overlaying (i.e., overlayData). This will set a secondary threshold
% based on p-values.
%
% 'pThreshold' -- All faces that have vertices with p-values above this digit
% will be removed from the overlay. Default = 0.05.
%
% 'lights' -- if this string is 'on' and you are generating a new figure,
% camera lights will be turned on. If 'off' they will not be added to the
% new figure.
%
% 'binarize' -- the number this is set to will make the whole map equal to
% this number
%
% 'clusterThreshold' -- this number is the minimum cluster size that will
% be patched
%
% 'outline' -- if 'true' only the outline of the data will be patched
%
% 'smoothSteps' -- number of times to smooth your data before patching
%
% 'smoothArea' -- area to smooth at once for every step (in number of
% closest vertices)
%
% 'smoothThreshold' -- 'above' will smooth all vertices that meet your
% thresholds. 'below' will smooth all vertices  we've removed (across the
% same thresholds).
%
% 'customColor' -- this is an n x 3 matrix of colors specifying a custom
% colormap
%
% 'binarizeClusters' -- if 'true' this will color each cluster a different
% color from your colormap
%
% 'clusterOrder' -- if set to 'random', the colors of clusters is randomly
% taken from your colormap. If 'descending' clusters will be organized by
% size (i.e., small clusters will be predominantly sample one side of your
% colormap and large clusters will be predominantly sample the other side
% of your colormap; this results in less color diversity).
%
% Complex call example:
% [overlay] = plotUnderlay(underlay, overlayData,'opacity',0.5)
%
% Alex Teghipco // 10/28/18 // alex.teghipco@uci.edu

%% 1.Parse options and initialize variables
% copy overlayData. This will not be edited by thresholds
overlayData2 = overlayData;

% Setup default options as a structure
options = struct('hemisphere','left','figHandle',[],'overlay',[],'limits',[],'threshold',[0 0],'opacity',1,'colorMap','jet','colorSampling','even','colorBins',1000,'pMap',[],'pThresh',0.05,'lights','on','multiOverlay','off','clusterThresh',0,'binarize',0,'inclZero','true','outline','false','smoothSteps',0,'smoothArea',1,'smoothThreshold','above','customColor',[],'binarizeClusters','false','clusterOrder','random','transparencyLimits',[],'transparencyThresholds',[],'transparencyData',[],'transparencyDirection','zero','modulateTransparency','false');

% Read in the acceptable argument names
optionNames = fieldnames(options);

% Check the number of arguments passed
nArgs = length(varargin);
if round(nArgs/2)~=nArgs/2
    error('You are missing an argument name somewhere in your list of inputs')
end

% Start up a waitbar...if matlab has been running for a while patching
% might be slow (e.g., bad RAM management in mac)
h = waitbar(0,'Checking/setting up variables');
titleHandle = get(findobj(h,'Type','axes'),'Title');
set(titleHandle,'FontSize',8)

% Assign supplied values to each argument in input
for pair = reshape(varargin,2,[]) %# pair is {propName;propValue}
    inpName = pair{1}; % make case insensitive by using lower() here but this can be buggy
    if any(strcmp(inpName,optionNames))
        options.(inpName) = pair{2};
    else
        error('%s is not a recognized parameter name',inpName)
    end
end

% If you did not provide transparency data, make that data overlay
if isempty(options.transparencyData) == 1
    options.transparencyData = overlayData;
end

% Create limits if they were not provided
if isempty(options.limits) == 1
    options.limits = [floor(min(overlayData)) ceil(max(overlayData))];
end
% if only a min or max was provided look at distance of provided value from
% min and from max. If closer to min, then set the provided value to the
% minimum limit and make get max of data, otherwise set value to max limit
% and get min from data
if length(options.limits) == 1
    limitTmp = [floor(min(overlayData)) ceil(max(overlayData))];
    optDist = pdist2(options.limits,limitTmp');
    if optDist(1) < optDist(2)
        options.limits = [options.limits optDist(2)];
    else
        options.limits = [optDist(1) options.limits];
    end
end

% Figure out which hemisphere the overlay should be plotted on
if contains(lower(options.hemisphere),lower({'left', 'lh'})) == 1
    options.hemisphere = 'left';
elseif contains(lower(options.hemisphere),lower({'right', 'rh'})) == 1
    options.hemisphere = 'right';
elseif (contains(lower(options.hemisphere),lower({'left', 'lh'})) == 1) && (contains(lower(options.hemisphere),lower({'right', 'rh'})) == 1)
    options.hemisphere = inputdlg('It looks like your file contains reference to both hemispheres...which hemisphere should I associate with this file? (type left or right)' ,'Could not find hemisphere');
elseif (contains(lower(options.hemisphere),lower({'left', 'lh'})) == 0) && (contains(lower(options.hemisphere),lower({'right', 'rh'})) == 0)
    options.hemisphere = inputdlg('It looks like your file does not contain reference to either hemisphere...which hemisphere should I associate with this file? (type left or right)' ,'Could not find hemisphere');
end

%% 2.Setup colormap
% Setup colormap
% If you did not provide an overlay structure, then map all of the provided data onto the colorMap you have
% selected
switch options.colorMap
    case 'jet'
        cMap = jet(options.colorBins);
    case 'parula'
        cMap = parula(options.colorBins);
    case 'hsv'
        cMap = hsv(options.colorBins);
    case 'hot'
        cMap = hot(options.colorBins);
    case 'cool'
        cMap = cool(options.colorBins);
    case 'spring'
        cMap = spring(options.colorBins);
    case 'summer'
        cMap = summer(options.colorBins);
    case 'autumn'
        cMap = autumn(options.colorBins);
    case 'winter'
        cMap = winter(options.colorBins);
    case 'gray'
        cMap = gray(options.colorBins);
    case 'bone'
        cMap = bone(options.colorBins);
    case 'copper'
        cMap = copper(options.colorBins);
    case 'pink'
        cMap = pink(options.colorBins);
    case 'lines'
        cMap = lines(options.colorBins);
    case 'colorcube'
        cMap = colorcube(options.colorBins);
    case 'prism'
        cMap = prism(options.colorBins);
    case 'Spectral'
        cMap=cbrewer('div', options.colorMap, options.colorBins);
    case 'RdYlBu'
        cMap = cbrewer('div', options.colorMap, options.colorBins);
    case 'RdGy'
        cMap = cbrewer('div', options.colorMap, options.colorBins);
    case 'RdBu'
        cMap = cbrewer('div', options.colorMap, options.colorBins);
    case 'PuOr'
        cMap = cbrewer('div', options.colorMap, options.colorBins);
    case 'PRGn'
        cMap = cbrewer('div', options.colorMap, options.colorBins);
    case 'PiYG'
        cMap = cbrewer('div', options.colorMap, options.colorBins);
    case 'BrBG'
        cMap = cbrewer('div', options.colorMap, options.colorBins);
    case 'YlOrRd'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'YlOrBr'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'YlGnBu'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'YlGn'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'Reds'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'RdPu'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'Purples'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'PuRd'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'PuBuGn'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'PuBu'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'OrRd'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'Oranges'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'Greys'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'Greens'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'GnBu'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'BuPu'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'BuGn'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'Blues'
        cMap = cbrewer('seq', options.colorMap, options.colorBins);
    case 'Set3'
        cMap = cbrewer('qual', options.colorMap, options.colorBins);
    case 'Set2'
        cMap = cbrewer('qual', options.colorMap, options.colorBins);
    case 'Set1'
        cMap = cbrewer('qual', options.colorMap, options.colorBins);
    case 'Pastel2'
        cMap = cbrewer('qual', options.colorMap, options.colorBins);
    case 'Pastel1'
        cMap = cbrewer('qual', options.colorMap, options.colorBins);
    case 'Paired'
        cMap = cbrewer('qual', options.colorMap, options.colorBins);
    case 'Dark2'
        cMap = cbrewer('qual', options.colorMap, options.colorBins);
    case 'Accent'
        cMap = cbrewer(options.colorBins);
    case 'inferno'
        cMap = inferno(options.colorBins);
    case 'plasma'
        cMap = plasma(options.colorBins);
    case 'vega10'
        cMap = vega10(options.colorBins);
    case 'vega20b'
        cMap = vega20b(options.colorBins);
    case 'vega20c'
        cMap = vega20c(options.colorBins);
    case 'viridis'
        cMap = viridis(options.colorBins);
    case 'thermal'
        cMap = cmocean(options.colorMap, options.colorBins);
    case 'haline'
        cMap = cmocean(options.colorMap, options.colorBins);
    case 'solar'
        cMap = cmocean(options.colorMap, options.colorBins);
    case 'ice'
        cMap = cmocean(options.colorMap, options.colorBins);
    case 'oxy'
        cMap = cmocean(options.colorMap, options.colorBins);
    case 'deep'
        cMap = cmocean(options.colorMap, options.colorBins);
    case 'dense'
        cMap = cmocean(options.colorMap, options.colorBins);
    case 'algae'
        cMap = cmocean(options.colorMap, options.colorBins);
    case 'matter'
        cMap = cmocean(options.colorMap, options.colorBins);
    case 'turbid'
        cMap = cmocean(options.colorMap, options.colorBins);
    case 'speed'
        cMap = cmocean(options.colorMap, options.colorBins);
    case 'amp'
        cMap = cmocean(options.colorMap, options.colorBins);
    case 'tempo'
        cMap = cmocean(options.colorMap, options.colorBins);
    case 'balance'
        cMap = cmocean(options.colorMap, options.colorBins);
    case 'delta'
        cMap = cmocean(options.colorMap, options.colorBins);
    case 'curl'
        cMap = cmocean(options.colorMap, options.colorBins);
    case 'phase'
        cMap = cmocean(options.colorMap, options.colorBins);
end

if isempty(options.customColor) == 0
    cMap = options.customColor;
end

%% 3. Apply thresholds
% Threshold data and remove all faces that include thresholded data
waitbar(.3,h,['Removing data between ' num2str(options.threshold(2)) ' and ' num2str(options.threshold(1))]);
% Copy faces since we will be removing them as we go through the thresholds
try
    faces = underlay.(options.hemisphere).Faces;
    vertList = (1:length(underlay.(options.hemisphere).Vertices))';
    data = overlayData;
catch
    if strcmp(options.hemisphere,'both') == 0
        close(h)
        error('It looks like you are trying to plot an overlay for a hemisphere that you have not yet loaded into FSviewer. Please load the hemisphere first!');
    else
        hemis = fieldnames(underlay);
        for hemii = 1:length(hemis)
            faces{hemii} = underlay.(hemis{hemii}).Faces;
        end
    end
end

if strcmp(options.hemisphere,'both') == 0
    switch options.inclZero
        case 'false'
            removeVert = find(overlayData <= options.threshold(2) & overlayData >= options.threshold(1));
        case 'true'
            removeVert = find(overlayData < options.threshold(2) & overlayData > options.threshold(1));
    end
    
    removeVertX = ismember(faces(:,1),removeVert);
    removeVertY = ismember(faces(:,2),removeVert);
    removeVertZ = ismember(faces(:,3),removeVert);
    removeVertXYZ = removeVertX+removeVertY+removeVertZ;
    removeVertXYZIdx = find(removeVertXYZ ~= 0);
    faces(removeVertXYZIdx,:) = [];
    vertList(removeVert) = [];
    data(removeVert) = [];
    
    % if you provided some p-values lets apply a second threshold
    if isempty(options.pMap) ~= 1
        waitbar(.35,h,['Removing data that is p > ' num2str(options.pThresh)]);
        removeVert = find(pMap > options.pThresh);
        removeVertX = ismember(faces(:,1),removeVert);
        removeVertY = ismember(faces(:,2),removeVert);
        removeVertZ = ismember(faces(:,3),removeVert);
        removeVertXYZ = removeVertX+removeVertY+removeVertZ;
        removeVertXYZIdx = find(removeVertXYZ ~= 0);
        faces(removeVertXYZIdx,:) = [];
        vertList(removeVert) = [];
        data(removeVert) = [];
    end
    
    % Need to make cluster Threshold greater than zero if you want outlines
    % of borders in your map. This is to trigger search for clusters in the
    % map. No cluster *can* be less than 1 in size so setting the threshold
    % to 0.1 will not affect cluster thresholding
    switch options.outline
        case 'true'
            options.clusterThresh = 0.1;
    end
    
    % Sam deal with binarize clusters. We need to force search for
    % clusters.
    switch options.binarizeClusters
        case 'true'
            options.clusterThresh = 0.1;
    end
    
    if options.clusterThresh > 0
        % make copy so vertList still exists for saving output
        vertListCopy = vertList;
        
        % set up cluster structure
        clusteri = 1;
        cluster{clusteri} = [];
        
        % start with a vertex in the brain that is not thresholded out
        %idx = find(overlayData ~= 0);
        area = vertListCopy(1);
        
        waitbar(.7,h,['Removing clusters less than  ' num2str(options.clusterThresh) ' in size. This may take some time if you have large clusters.' ]);
        
        % we will update a list of vertices we haven't looked at. If it's
        % empty, stop analysis
        while isempty(vertListCopy) == 0
            
            % As long as area is not empty
            while isempty(area) == 0
                %disp(num2str(length(vertListCopy)))
                
                % Remove any vertices in area that are not in vertList
                % (i.e., were are below the threshold) and remove from area
                [C,ia] = setdiff(area,vertListCopy);
                area(ia) = [];
                
                % Remove vertices in the area from the list of vertices we
                % haven't looked at
                [C,ia,ib] = intersect(vertListCopy,area);
                vertListCopy(ia) = [];
                
                % Assign remainder of vertices in area to a cluster cell
                cluster{clusteri} = vertcat(cluster{clusteri},area);
                
                % find all faces that border the area
                vertFaceX = ismember(faces(:,1),area);
                vertFaceY = ismember(faces(:,2),area);
                vertFaceZ = ismember(faces(:,3),area);
                vertFaceXYZ = vertFaceX+vertFaceY+vertFaceZ;
                vertFaceXYZIdx = find(vertFaceXYZ ~= 0);
                
                area = unique(faces(vertFaceXYZIdx,:));
                
                % if area is only 1 face row matches the area sometimes
                % there is an error because of how unique organizes data
                if size(area,1) < size(area,2)
                    area = area';
                end
                
                % remove those faces already part of the cluster
                [C,ia,ib] = intersect(area,cluster{clusteri});
                area(ia) = [];
            end
            
            if isempty(vertListCopy) == 0
                area = vertListCopy(1);
                clusteri = clusteri+1;
                cluster{clusteri} = [];
            end
        end
        
        % get size of all cells
        clusterLen = cellfun('length',cluster);
        
        % get all vertices above cluster threshold
        clustIdx = find(clusterLen < options.clusterThresh);
        clustVert = vertcat(cluster{clustIdx});
        cluster(clustIdx) = [];
        
        % remove clusters below threshold from overlay data and vertex list
        % match every index in clustVert to that of vertList
        [C, ia, removeVert] = intersect(clustVert,vertList);
        vertList(removeVert) = [];
        data(removeVert) = [];
        %overlayData(removeVert) = 0;
        
        % remove faces not within the cluster
        removeVertX = ismember(faces(:,1),clustVert);
        removeVertY = ismember(faces(:,2),clustVert);
        removeVertZ = ismember(faces(:,3),clustVert);
        removeVertXYZ = removeVertX+removeVertY+removeVertZ;
        removeVertXYZIdx = find(removeVertXYZ ~= 0);
        faces(removeVertXYZIdx,:) = [];
        
        % save maximum cluster size to options
        options.clusterLimit = max(clusterLen);
        options.clusters = cluster;
    end
end

% If you asked to binarize, lets do that now
% overlayData(removeVert) = 0;
if options.binarize ~= 0
    idx = find(overlayData ~= 0);
    overlayData(idx) = options.binarize; % you may be able to just remove this...
    data(:) = options.binarize; % data is thresholded as we go so it can be changed at once
end

% See if we should only keep the outline of thresholded clusters
switch options.outline
    case 'true'
        waitbar(.8,h,['Creating borders around clusters...this will take time']);
        % if we do want to make an outline, do so for each cluster
        for clusteri = 1:length(cluster)
            % We want to make a copy of our original faces because we will
            % be looking for vertices in our cluster w/at least one
            % neighbor outside cluster
            facesTmp = underlay.(options.hemisphere).Faces;
            % save cluster
            clusterTmp = cluster{clusteri};
            % loop over all vertices
            for verti = 1:length(clusterTmp)
                faceX = ismember(facesTmp(:,1),clusterTmp(verti));
                faceY = ismember(facesTmp(:,2),clusterTmp(verti));
                faceZ = ismember(facesTmp(:,3),clusterTmp(verti));
                faceXYZ = faceX+faceY+faceZ;
                faceXYZIdx = find(faceXYZ ~= 0);
                
                % neighborhood for vertex
                area = unique(facesTmp(faceXYZIdx,:));
                
                % find the number of neighbors that are not within cluster
                [C,ia] = setdiff(area,clusterTmp);
                
                % if there are neighbors for the vertex not in cluster mark
                % this cluster as part of the border
                if length(C) >= 1 % 1 is the number of neighbors for vertex that are not in cluster
                    border(verti) = 1;
                else
                    border(verti) = 0;
                end
            end
            % find all vertices that are not border
            notBorder = find(border == 0);
            
            % remove them from the list of vertices within cluster
            cluster{clusteri}(notBorder) = [];
            clear border
        end
        
        % combine vertices from all clusters
        clustVert = vertcat(cluster{:});
        
        % remove any vertices that are not in clusters from data
        [C, removeVert] = setdiff(vertList,clustVert);
        vertList(removeVert) = [];
        data(removeVert) = [];
        %overlayData(removeVert) = 0;
        
        % remove faces not within the cluster
        removeVertX = ~ismember(faces(:,1),clustVert);
        removeVertY = ~ismember(faces(:,2),clustVert);
        removeVertZ = ~ismember(faces(:,3),clustVert);
        removeVertXYZ = removeVertX+removeVertY+removeVertZ;
        removeVertXYZIdx = find(removeVertXYZ > 2); % if you change it to 1 you will have thinner outlines
        faces(removeVertXYZIdx,:) = [];
end

% now smooth the data if you asked for some smoothing
if options.smoothArea > 0 && options.smoothSteps > 0
    waitbar(.9,h,['Smoothing data...this will take time']);
    % make copy of vertices from underlay (we will use these)
    % and generate index for each vertex
    tmpVert = underlay.(options.hemisphere).Vertices;
    vertIdx = 1:length(tmpVert);
    
    % get vertices below and above our thresholds
    aboveThreshVert = vertList;
    [C, ia] = setdiff(vertIdx,vertList);
    
    % because smoothing will overwrite data lets set everything below
    % threshold in overlayData to zero
    belowThreshVert = vertIdx(ia);
    overlayData(belowThreshVert) = 0;
    
    % identify which vertices to smooth based on your argument
    switch options.smoothThreshold
        case 'above'
            % above means we will be smoothing only vertices that meet all
            % of the various thresholds we've gone through so far.
            % This means the border of the thresholded area will contract.
            % You will be smoothing vertices with some value greater than
            % zero, with thresholded values that are all zeros.
            toSmooth = aboveThreshVert;
            
        case 'below'
            % below means we will be smoothing vertices that do not meet
            % all of the various thresholds.This means the border of the
            % thresholded area will expand. You will be smoothing voxels on
            % the edge of thresholded values, which are all zeros. This
            % will drive the mean of these edge voxels down.
            toSmooth = belowThreshVert;
    end
    
    %get nearest X vertices to each vertex to smooth (user selected area X)
    [~,neighborhood] = pdist2(tmpVert,tmpVert(toSmooth,:),'euclidean','Smallest',options.smoothArea);
    
    % now smooth
    for smoothi = 1:options.smoothSteps
        overlayData(toSmooth) = mean(overlayData(neighborhood),1);
    end
    % smoothing might bleed into faces we have removed from the patch so we
    % need to load up the original faces and remove only vertices with
    % zeros.
    faces = underlay.(options.hemisphere).Faces;
    idx = find(overlayData == 0);
    
    % remove faces not within the cluster
    removeVertX = ismember(faces(:,1),idx);
    removeVertY = ismember(faces(:,2),idx);
    removeVertZ = ismember(faces(:,3),idx);
    removeVertXYZ = removeVertX+removeVertY+removeVertZ;
    removeVertXYZIdx = find(removeVertXYZ ~= 0);
    faces(removeVertXYZIdx,:) = [];
end

% vertList is all the vertices that survive various thresholds. Select all
% other vertices and make their data zero
allVert = 1:length(underlay.(options.hemisphere).Vertices);
[C, removeVert] = setdiff(allVert,vertList);
overlayData(removeVert) = 0;

% This will take all clusters and binarize them
switch options.binarizeClusters
    case 'true'
        % one problem is that smaller clusters will predominantly map onto
        % one end of the spectrum unless they are shuffled so lets do that
        % now
        switch options.clusterOrder
            case 'random'
                randi = randperm(length(cluster));
                cluster = cluster(randi);
        end
        
        for clusteri = 1:length(cluster)
            overlayData(cluster{clusteri}) = clusteri;
        end
        options.limits = [min(overlayData) max(overlayData)];
        
end

% map colors onto data
switch options.colorSampling
    case 'center on zero'
        cMapPos = cMap((1:floor(length(cMap)/2)),:);
        cMapNeg = cMap(floor((length(cMap)+1)/2):end,:);
        cMap = vertcat(cMapPos,cMapNeg);
        cDataNeg = linspace(options.limits(1),0,options.colorBins/2);
        cDataPos = linspace(0,options.limits(2),options.colorBins/2);
        cData = horzcat(cDataNeg,cDataPos);
    case 'even'
        cData = linspace(options.limits(1),options.limits(2),options.colorBins);
end

cDataMatch = abs(bsxfun(@gt,overlayData,cData));
cDataIdx = sum( abs( cumprod( cDataMatch, 2 ) ) > 0, 2 ) + 1;

% it is possible for value to be equal to maximum or minimum
if max(cDataIdx) > length(cData)
    idx = find(cDataIdx > length(cData));
    cDataIdx(idx) = length(cData);
end
if min(cDataIdx) < 1
    idx = find(cDataIdx < 1);
    cDataIdx(idx) = 1;
end
ocData = cMap(cDataIdx,:);



%% 4. Patch data
% if you provided a figure to patch, use that, otherwise lets rebuild the
% underlay in a new figure
waitbar(.95,h,'Patching overlay');
if isempty(options.figHandle) == 0
    % if you gave an overlay, delete it now as long as multioverlay is off
    if isempty(options.overlay) == 0 && strcmp(options.multiOverlay,'off')
        delete(options.overlay)
    end
    % get current figure
    figure(options.figHandle)
    
    if strcmp(options.hemisphere,'both') == 0
        %overlay = patch('Faces',faces,'Vertices',underlay.(options.hemisphere).Vertices,'FaceVertexCData',overlayData,'facealpha',options.opacity,'CDataMapping','scaled','facecolor','interp','edgecolor','none');
        
        switch options.modulateTransparency
            case 'thresholded'
                switch options.transparencyCenter
                    case 'zero'
                        FaceVertexAlphaData = zeros([length(options.transparencyData),1]);
                        idxPos = find(options.transparencyData > 0);
                        idxNeg = find(options.transparencyData < 0);
                        FaceVertexAlphaDataPos = options.transparencyData(idxPos);
                        FaceVertexAlphaDataNeg = options.transparencyData(idxNeg);
                        FaceVertexAlphaDataNeg = abs(FaceVertexAlphaDataNeg);
                       
                        FaceVertexAlphaDataPos = (FaceVertexAlphaDataPos-min(FaceVertexAlphaDataPos))*(options.transparencyMax-options.transparencyMin)/(max(FaceVertexAlphaDataPos)-min(FaceVertexAlphaDataPos)) + options.transparencyMin;
                        FaceVertexAlphaDataNeg = (FaceVertexAlphaDataNeg-min(FaceVertexAlphaDataNeg))*(options.transparencyMax-options.transparencyMin)/(max(FaceVertexAlphaDataNeg)-min(FaceVertexAlphaDataNeg)) + options.transparencyMin;
                        FaceVertexAlphaData(idxPos) = FaceVertexAlphaDataPos;
                        FaceVertexAlphaData(idxNeg) = FaceVertexAlphaDataNeg;
                        
                    case 'minimum'
                        FaceVertexAlphaData = options.transparencyData;
                        FaceVertexAlphaData = (FaceVertexAlphaData-min(FaceVertexAlphaData))*(options.transparencyMax-options.transparencyMin)/(max(FaceVertexAlphaData)-min(FaceVertexAlphaData)) + options.transparencyMin;
                        
                    case 'maximum'
                        maxVal = options.transparencyMax;
                        minVal = options.transparencyMin;
                        options.transparencyMax = minVal;
                        options.transparencyMin = maxVal;
                        
                        FaceVertexAlphaData = options.transparencyData;
                        FaceVertexAlphaData = (FaceVertexAlphaData-min(FaceVertexAlphaData))*(options.transparencyMax-options.transparencyMin)/(max(FaceVertexAlphaData)-min(FaceVertexAlphaData)) + options.transparencyMin;
                end
                
                overlay = patch('Faces',faces,'Vertices',underlay.(options.hemisphere).Vertices,'FaceVertexCData',ocData,'FaceVertexAlphaData',FaceVertexAlphaData, 'AlphaDataMapping' ,'none','facealpha',options.opacity,'CDataMapping','direct','facecolor','interp','edgecolor','none');
                overlay.FaceAlpha = 'flat';
                
            case 'unthresholded'
                % make all untrehsolded values transparency 1
                % we will be working with faces
                
                % make copy of unthresholded faces
                faces2 = underlay.(options.hemisphere).Faces;
                
                % now find idx of all unthresholded faces
                [C,unthreshIdx] = setdiff(faces2,faces,'rows');
                
                % and idx of all thresholded faces
                [C,threshIdx, ib] = intersect(faces2,faces,'rows');
                
                switch options.transparencyCenter
                    case 'zero'
                        % set up face opacity for all faces and make the
                        % thresholded faces opacity max
                        faceOpacity = zeros([length(faces2),1]);
                        faceOpacity(threshIdx) = options.transparencyMax;
                        
                        % get mean data for each unthresholded face
                        for faci = 1:length(unthreshIdx)
                            meanFaceData(faci,1) = mean(options.transparencyData(faces2(unthreshIdx(faci),:)));
                        end
                        
                        idxPos = find(meanFaceData > 0);
                        idxNeg = find(meanFaceData < 0);
                        
                        faceOpacityPos = meanFaceData(idxPos);
                        faceOpacityNeg = meanFaceData(idxNeg);
                        faceOpacityNeg = abs(faceOpacityNeg);
                        
                        
                        faceOpacityPosNorm = (faceOpacityPos-min(faceOpacityPos))*(options.transparencyMax-options.transparencyMin)/(max(faceOpacityPos)-min(faceOpacityPos)) + options.transparencyMin;
                        faceOpacityNegNorm = (faceOpacityNeg-min(faceOpacityNeg))*(options.transparencyMax-options.transparencyMin)/(max(faceOpacityNeg)-min(faceOpacityNeg)) + options.transparencyMin;
                        
                        faceOpacity(unthreshIdx(idxPos)) = faceOpacityPosNorm;
                        faceOpacity(unthreshIdx(idxNeg)) = faceOpacityNegNorm;
                        
                        FaceVertexAlphaData = faceOpacity;
                        
                    case 'minimum'
                        % set up face opacity for all faces and make the
                        % thresholded faces opacity max
                        faceOpacity = zeros([length(faces2),1]);
                        faceOpacity(threshIdx) = options.transparencyMax;
                        
                        % get mean data for each unthresholded face
                        for faci = 1:length(unthreshIdx)
                            meanFaceData(faci,1) = mean(options.transparencyData(faces2(unthreshIdx(faci),:)));
                        end
                        
                        meanFaceData = (meanFaceData-min(meanFaceData))*(options.transparencyMax-options.transparencyMin)/(max(meanFaceData)-min(meanFaceData)) + options.transparencyMin;
                        faceOpacity(unthreshIdx) = meanFaceData;
                        FaceVertexAlphaData = faceOpacity;
                        
                    case 'maximum'
                        maxVal = options.transparencyMax;
                        minVal = options.transparencyMin;
                        options.transparencyMax = minVal;
                        options.transparencyMin = maxVal;
                        
                        % set up face opacity for all faces and make the
                        % thresholded faces opacity max
                        faceOpacity = zeros([length(faces2),1]);
                        faceOpacity(threshIdx) = options.transparencyMax;
                        
                        % get mean data for each unthresholded face
                        for faci = 1:length(unthreshIdx)
                            meanFaceData(faci,1) = mean(options.transparencyData(faces2(unthreshIdx(faci),:)));
                        end
                        
                        meanFaceData = (meanFaceData-min(meanFaceData))*(options.transparencyMax-options.transparencyMin)/(max(meanFaceData)-min(meanFaceData)) + options.transparencyMin;
                        faceOpacity(unthreshIdx) = meanFaceData;
                        FaceVertexAlphaData = faceOpacity;
                end
                
                % remap data because we are manually plotting colors...
                cDataMatch = abs(bsxfun(@gt,overlayData2,cData));
                cDataIdx = sum( abs( cumprod( cDataMatch, 2 ) ) > 0, 2 ) + 1;
                
                % it is possible for value to be equal to maximum or minimum
                if max(cDataIdx) > length(cData)
                    idx = find(cDataIdx > length(cData));
                    cDataIdx(idx) = length(cData);
                end
                if min(cDataIdx) < 1
                    idx = find(cDataIdx < 1);
                    cDataIdx(idx) = 1;
                end
                ocData = cMap(cDataIdx,:);
                
                overlay = patch('Faces',faces2,'Vertices',underlay.(options.hemisphere).Vertices,'FaceVertexCData',ocData,'FaceVertexAlphaData',FaceVertexAlphaData, 'AlphaDataMapping' ,'scaled','facealpha',options.opacity,'CDataMapping','direct','facecolor','interp','edgecolor','none');
                overlay.FaceAlpha = 'flat';
                
            case 'false'
                % overlay = patch('Faces',faces,'Vertices',underlay.(options.hemisphere).Vertices,'FaceVertexCData',ocData,'FaceVertexAlphaData',FaceVertexAlphaData, 'AlphaDataMapping' ,'none','facealpha',options.opacity,'CDataMapping','direct','facecolor','interp','edgecolor','none');
                overlay = patch('Faces',faces,'Vertices',underlay.(options.hemisphere).Vertices,'FaceVertexCData',ocData,'facealpha',options.opacity,'CDataMapping','direct','facecolor','interp','edgecolor','none');
        end
    else
        for hemii = 1:length(faces)
            %ocData = ones([size(underlay.(hemis{hemii}).Vertices,1);
            overlay = patch('Faces',faces{hemii},'Vertices',underlay.(hemis{hemii}).Vertices,'FaceVertexCData',ones([size(underlay.(hemis{hemii}).Vertices,1),3]),'facealpha',0,'CDataMapping','scaled','facecolor','interp','edgecolor','none');
        end
    end
    
    colormap(cMap);
    caxis(options.limits)
    
    ticks = linspace(options.limits(1),options.limits(2),11);
    switch options.colorSampling
        case 'even'
            tickLabels = ticks;
            
        case 'center on zero'
            tickLabels = [linspace(options.limits(1),0,6) linspace(0,options.limits(2),6)];
            idx = find(tickLabels == 0);
            tickLabels(idx(1)) = [];
    end
    options.colorbar = colorbar('TickLabels',tickLabels,'Ticks',ticks);
    
else
    options.figHandle = figure;
    for hemii = 1:length(fieldnames(underlay))
        hemiNames = fieldnames(underlay);
        underlay.(hemiNames{hemii}) = patch('Faces',hemiNames{hemii}.Faces,'Vertices',hemiNames{hemii}.Vertices,'FaceVertexCData',hemiNames{hemii}.FaceVertexCData,'facealpha',1,'CDataMapping','direct','facecolor','interp','edgecolor','none');
    end
    axis off vis3d equal tight;
    material dull
    switch options.lights
        case 'on'
            camlight(-90,0);
            camlight(90,0);
            camlight(0,0);
            camlight(180,0);
            %camlight(180,90); % this will make it REALLY bright
    end
    if isempty(options.overlay) == 0 && strcmp(options.multiOverlay,'off')
        delete(options.overlay)
    end
    
    if strcmp(options.hemisphere,'both') == 0
        %overlay = patch('Faces',faces,'Vertices',underlay.(options.hemisphere).Vertices,'FaceVertexCData',overlayData,'facealpha',options.opacity,'CDataMapping','scaled','facecolor','interp','edgecolor','none');
        overlay = patch('Faces',faces,'Vertices',underlay.(options.hemisphere).Vertices,'FaceVertexCData',ocData,'facealpha',options.opacity,'CDataMapping','direct','facecolor','interp','edgecolor','none');
        
    else
        for hemii = 1:length(faces)
            %overlay = patch('Faces',faces{hemii},'Vertices',underlay.(hemis{hemii}).Vertices,'FaceVertexCData',zeros([size(underlay.(hemis{hemii}).Vertices,1), size(underlay.(hemis{hemii}).Vertices,2)]),'facealpha',0,'CDataMapping','scaled','facecolor','interp','edgecolor','none');
            overlay = patch('Faces',faces{hemii},'Vertices',underlay.(hemis{hemii}).Vertices,'FaceVertexCData',ones([size(underlay.(hemis{hemii}).Vertices,1),3]),'facealpha',0,'CDataMapping','scaled','facecolor','interp','edgecolor','none');
        end
    end
    
    colormap(cMap);
    caxis(options.limits)
    
    ticks = linspace(options.limits(1),options.limits(2),11);
    switch options.colorSampling
        case 'even'
            tickLabels = ticks;
            
        case 'center on zero'
            tickLabels = [linspace(options.limits(1),0,6) linspace(0,options.limits(2),6)];
            idx = find(tickLabels == 0);
            tickLabels(idx(1)) = [];
    end
    options.colorbar = colorbar('TickLabels',tickLabels,'Ticks',ticks);
end

waitbar(1,h,'Saving overlay and underlay');

% fix a few parameters for visualization
overlay.SpecularStrength = 0;
if strcmp(options.hemisphere,'left') == 1
    view([-90 0]);
elseif strcmp(options.hemisphere,'right') == 1
    view([90 0]);
end
%options.data = data;
options.verts = vertList;
options.overlayData = overlayData;
options.data = data;

% setup outputs
varargout{1} = underlay;
varargout{2} = overlay;
varargout{3} = options.figHandle;
varargout{4} = options;
close(h)